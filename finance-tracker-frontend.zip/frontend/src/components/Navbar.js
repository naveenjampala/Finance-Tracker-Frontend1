import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { username, logout, isAuthenticated } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!isAuthenticated) return null;

  return (
    <nav style={styles.nav}>
      <div style={styles.brand}>💰 Finance Tracker</div>
      <div style={styles.links}>
        <Link to="/" style={styles.link}>Dashboard</Link>
        <Link to="/transactions" style={styles.link}>Transactions</Link>
        <Link to="/budgets" style={styles.link}>Budgets</Link>
      </div>
      <div style={styles.userSection}>
        <span style={styles.username}>Hi, {username}</span>
        <button onClick={handleLogout} style={styles.logoutBtn}>Logout</button>
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '14px 32px',
    background: '#1a1a2e',
    color: '#fff',
    flexWrap: 'wrap',
  },
  brand: { fontWeight: 700, fontSize: 18 },
  links: { display: 'flex', gap: 24 },
  link: { color: '#c9c9e0', fontWeight: 500 },
  userSection: { display: 'flex', alignItems: 'center', gap: 16 },
  username: { color: '#c9c9e0', fontSize: 14 },
  logoutBtn: {
    background: '#e94560',
    color: '#fff',
    border: 'none',
    padding: '8px 16px',
    borderRadius: 6,
    fontSize: 14,
  },
};
