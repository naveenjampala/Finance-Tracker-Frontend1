import React, { useEffect, useState, useCallback } from 'react';
import { getBudgetStatus, createBudget, deleteBudget } from '../services/budgetService';

const now = new Date();
const emptyForm = { category: '', monthlyLimit: '' };

export default function Budgets() {
  const [month] = useState(now.getMonth() + 1);
  const [year] = useState(now.getFullYear());
  const [statuses, setStatuses] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getBudgetStatus(month, year);
      setStatuses(res.data);
    } catch (err) {
      setError('Failed to load budgets');
    } finally {
      setLoading(false);
    }
  }, [month, year]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await createBudget({ ...form, monthlyLimit: parseFloat(form.monthlyLimit), month, year });
      setForm(emptyForm);
      fetchData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save budget');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this budget?')) return;
    try {
      await deleteBudget(id);
      fetchData();
    } catch (err) {
      setError('Failed to delete budget');
    }
  };

  return (
    <div style={styles.page}>
      <h2>Budgets — {new Date(2000, month - 1).toLocaleString('default', { month: 'long' })} {year}</h2>

      {error && <div style={styles.error}>{error}</div>}

      <form style={styles.form} onSubmit={handleSubmit}>
        <input name="category" placeholder="Category (e.g. Food)" value={form.category} onChange={handleChange} style={styles.input} required />
        <input name="monthlyLimit" type="number" step="0.01" placeholder="Monthly Limit" value={form.monthlyLimit} onChange={handleChange} style={styles.input} required />
        <button type="submit" style={styles.addBtn}>Set Budget</button>
      </form>

      {loading ? <p>Loading...</p> : (
        <div style={styles.grid}>
          {statuses.length === 0 && <p style={{ color: '#999' }}>No budgets set for this month yet.</p>}
          {statuses.map((b) => {
            const pct = Math.min(b.percentUsed, 100);
            return (
              <div key={b.budgetId} style={styles.card}>
                <div style={styles.cardHeader}>
                  <strong>{b.category}</strong>
                  <button style={styles.deleteBtn} onClick={() => handleDelete(b.budgetId)}>✕</button>
                </div>
                <div style={styles.barTrack}>
                  <div style={{ ...styles.barFill, width: `${pct}%`, background: b.overBudget ? '#e94560' : '#2a9d8f' }} />
                </div>
                <div style={styles.cardStats}>
                  <span>₹{Number(b.spent).toLocaleString()} / ₹{Number(b.monthlyLimit).toLocaleString()}</span>
                  <span style={{ color: b.overBudget ? '#e94560' : '#666' }}>{b.percentUsed}%</span>
                </div>
                {b.overBudget && <div style={styles.overBadge}>⚠️ Over budget</div>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

const styles = {
  page: { padding: 32, maxWidth: 1100, margin: '0 auto' },
  form: { display: 'flex', gap: 10, flexWrap: 'wrap', background: '#fff', padding: 16, borderRadius: 10, marginBottom: 24, boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  input: { flex: 1, minWidth: 150, padding: '10px 12px', border: '1px solid #ddd', borderRadius: 6, fontSize: 14 },
  addBtn: { padding: '10px 20px', background: '#0f3460', color: '#fff', border: 'none', borderRadius: 6, fontWeight: 600 },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 },
  card: { background: '#fff', padding: 18, borderRadius: 10, boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  cardHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  deleteBtn: { border: 'none', background: 'transparent', color: '#999', fontSize: 14, cursor: 'pointer' },
  barTrack: { height: 10, background: '#eee', borderRadius: 5, overflow: 'hidden', marginBottom: 8 },
  barFill: { height: '100%', borderRadius: 5, transition: 'width 0.3s' },
  cardStats: { display: 'flex', justifyContent: 'space-between', fontSize: 13, color: '#333' },
  overBadge: { marginTop: 10, fontSize: 12, color: '#e94560', fontWeight: 600 },
  error: { background: '#ffe5e9', color: '#e94560', padding: '10px 14px', borderRadius: 6, marginBottom: 16 },
};
