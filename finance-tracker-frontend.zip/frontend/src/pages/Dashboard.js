import React, { useEffect, useState, useCallback } from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { getDashboardSummary } from '../services/dashboardService';
import { exportCsv, exportPdf } from '../services/exportService';

const COLORS = ['#e94560', '#0f3460', '#16213e', '#e9c46a', '#2a9d8f', '#f4a261', '#8d5fd3', '#00b894'];

const now = new Date();

export default function Dashboard() {
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [year, setYear] = useState(now.getFullYear());
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchSummary = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getDashboardSummary(month, year);
      setSummary(res.data);
      setError('');
    } catch (err) {
      setError('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }, [month, year]);

  useEffect(() => { fetchSummary(); }, [fetchSummary]);

  const pieData = summary
    ? Object.entries(summary.expensesByCategory || {}).map(([name, value]) => ({ name, value }))
    : [];

  const budgetBarData = summary
    ? summary.budgetStatuses.map((b) => ({
        category: b.category,
        Spent: b.spent,
        Limit: b.monthlyLimit,
      }))
    : [];

  return (
    <div style={styles.page}>
      <div style={styles.headerRow}>
        <h2 style={{ margin: 0 }}>Dashboard</h2>
        <div style={styles.controls}>
          <select value={month} onChange={(e) => setMonth(Number(e.target.value))} style={styles.select}>
            {Array.from({ length: 12 }, (_, i) => i + 1).map((m) => (
              <option key={m} value={m}>{new Date(2000, m - 1).toLocaleString('default', { month: 'long' })}</option>
            ))}
          </select>
          <input
            type="number"
            value={year}
            onChange={(e) => setYear(Number(e.target.value))}
            style={{ ...styles.select, width: 90 }}
          />
          <button style={styles.exportBtn} onClick={() => exportCsv(month, year)}>Export CSV</button>
          <button style={styles.exportBtn} onClick={() => exportPdf(month, year)}>Export PDF</button>
        </div>
      </div>

      {error && <div style={styles.error}>{error}</div>}
      {loading && <p>Loading...</p>}

      {!loading && summary && (
        <>
          <div style={styles.cardsRow}>
            <div style={{ ...styles.summaryCard, borderLeft: '4px solid #2a9d8f' }}>
              <div style={styles.cardLabel}>Total Income</div>
              <div style={styles.cardValue}>₹{Number(summary.totalIncome).toLocaleString()}</div>
            </div>
            <div style={{ ...styles.summaryCard, borderLeft: '4px solid #e94560' }}>
              <div style={styles.cardLabel}>Total Expense</div>
              <div style={styles.cardValue}>₹{Number(summary.totalExpense).toLocaleString()}</div>
            </div>
            <div style={{ ...styles.summaryCard, borderLeft: '4px solid #0f3460' }}>
              <div style={styles.cardLabel}>Balance</div>
              <div style={styles.cardValue}>₹{Number(summary.balance).toLocaleString()}</div>
            </div>
          </div>

          <div style={styles.chartsRow}>
            <div style={styles.chartCard}>
              <h4>Expenses by Category</h4>
              {pieData.length === 0 ? <p style={styles.empty}>No expenses recorded this month.</p> : (
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>
                      {pieData.map((entry, index) => (
                        <Cell key={index} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>

            <div style={styles.chartCard}>
              <h4>Budget vs Spent</h4>
              {budgetBarData.length === 0 ? <p style={styles.empty}>No budgets set for this month.</p> : (
                <ResponsiveContainer width="100%" height={280}>
                  <BarChart data={budgetBarData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="category" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="Limit" fill="#0f3460" />
                    <Bar dataKey="Spent" fill="#e94560" />
                  </BarChart>
                </ResponsiveContainer>
              )}
            </div>
          </div>

          {summary.budgetStatuses.some((b) => b.overBudget) && (
            <div style={styles.alertBox}>
              ⚠️ Over budget in: {summary.budgetStatuses.filter((b) => b.overBudget).map((b) => b.category).join(', ')}
            </div>
          )}
        </>
      )}
    </div>
  );
}

const styles = {
  page: { padding: 32, maxWidth: 1100, margin: '0 auto' },
  headerRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 12, marginBottom: 24 },
  controls: { display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' },
  select: { padding: '8px 10px', borderRadius: 6, border: '1px solid #ddd' },
  exportBtn: { padding: '8px 14px', borderRadius: 6, border: 'none', background: '#0f3460', color: '#fff', fontSize: 13, fontWeight: 600 },
  cardsRow: { display: 'flex', gap: 20, flexWrap: 'wrap', marginBottom: 24 },
  summaryCard: { flex: '1 1 200px', background: '#fff', padding: 20, borderRadius: 10, boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  cardLabel: { fontSize: 13, color: '#666', marginBottom: 6 },
  cardValue: { fontSize: 26, fontWeight: 700 },
  chartsRow: { display: 'flex', gap: 20, flexWrap: 'wrap' },
  chartCard: { flex: '1 1 400px', background: '#fff', padding: 20, borderRadius: 10, boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  empty: { color: '#999', fontSize: 14 },
  error: { background: '#ffe5e9', color: '#e94560', padding: '10px 14px', borderRadius: 6, marginBottom: 16 },
  alertBox: { marginTop: 20, background: '#fff3cd', color: '#856404', padding: '12px 16px', borderRadius: 8, fontWeight: 600 },
};
