import React, { useEffect, useState } from 'react';
import { getTransactions, createTransaction, updateTransaction, deleteTransaction } from '../services/transactionService';

const emptyForm = { type: 'EXPENSE', category: '', amount: '', date: new Date().toISOString().slice(0, 10), description: '' };

export default function Transactions() {
  const [transactions, setTransactions] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await getTransactions();
      setTransactions(res.data);
    } catch (err) {
      setError('Failed to load transactions');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      const payload = { ...form, amount: parseFloat(form.amount) };
      if (editingId) {
        await updateTransaction(editingId, payload);
      } else {
        await createTransaction(payload);
      }
      setForm(emptyForm);
      setEditingId(null);
      fetchData();
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to save transaction');
    }
  };

  const handleEdit = (t) => {
    setForm({ type: t.type, category: t.category, amount: t.amount, date: t.date, description: t.description || '' });
    setEditingId(t.id);
  };

  const handleCancelEdit = () => {
    setForm(emptyForm);
    setEditingId(null);
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Delete this transaction?')) return;
    try {
      await deleteTransaction(id);
      fetchData();
    } catch (err) {
      setError('Failed to delete transaction');
    }
  };

  return (
    <div style={styles.page}>
      <h2>Transactions</h2>

      {error && <div style={styles.error}>{error}</div>}

      <form style={styles.form} onSubmit={handleSubmit}>
        <select name="type" value={form.type} onChange={handleChange} style={styles.input}>
          <option value="EXPENSE">Expense</option>
          <option value="INCOME">Income</option>
        </select>
        <input name="category" placeholder="Category (e.g. Food)" value={form.category} onChange={handleChange} style={styles.input} required />
        <input name="amount" type="number" step="0.01" placeholder="Amount" value={form.amount} onChange={handleChange} style={styles.input} required />
        <input name="date" type="date" value={form.date} onChange={handleChange} style={styles.input} required />
        <input name="description" placeholder="Description (optional)" value={form.description} onChange={handleChange} style={{ ...styles.input, flex: 2 }} />
        <button type="submit" style={styles.addBtn}>{editingId ? 'Update' : 'Add'}</button>
        {editingId && <button type="button" onClick={handleCancelEdit} style={styles.cancelBtn}>Cancel</button>}
      </form>

      {loading ? <p>Loading...</p> : (
        <table style={styles.table}>
          <thead>
            <tr>
              <th style={styles.th}>Date</th>
              <th style={styles.th}>Type</th>
              <th style={styles.th}>Category</th>
              <th style={styles.th}>Amount</th>
              <th style={styles.th}>Description</th>
              <th style={styles.th}></th>
            </tr>
          </thead>
          <tbody>
            {transactions.length === 0 && (
              <tr><td colSpan={6} style={{ padding: 20, textAlign: 'center', color: '#999' }}>No transactions yet</td></tr>
            )}
            {transactions.map((t) => (
              <tr key={t.id}>
                <td style={styles.td}>{t.date}</td>
                <td style={styles.td}>
                  <span style={{ ...styles.badge, background: t.type === 'INCOME' ? '#d4f4dd' : '#ffe5e9', color: t.type === 'INCOME' ? '#2a9d8f' : '#e94560' }}>
                    {t.type}
                  </span>
                </td>
                <td style={styles.td}>{t.category}</td>
                <td style={styles.td}>₹{Number(t.amount).toLocaleString()}</td>
                <td style={styles.td}>{t.description}</td>
                <td style={styles.td}>
                  <button style={styles.smallBtn} onClick={() => handleEdit(t)}>Edit</button>
                  <button style={{ ...styles.smallBtn, background: '#e94560', color: '#fff' }} onClick={() => handleDelete(t.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const styles = {
  page: { padding: 32, maxWidth: 1100, margin: '0 auto' },
  form: { display: 'flex', gap: 10, flexWrap: 'wrap', background: '#fff', padding: 16, borderRadius: 10, marginBottom: 24, boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  input: { flex: 1, minWidth: 120, padding: '10px 12px', border: '1px solid #ddd', borderRadius: 6, fontSize: 14 },
  addBtn: { padding: '10px 20px', background: '#0f3460', color: '#fff', border: 'none', borderRadius: 6, fontWeight: 600 },
  cancelBtn: { padding: '10px 20px', background: '#eee', color: '#333', border: 'none', borderRadius: 6, fontWeight: 600 },
  table: { width: '100%', borderCollapse: 'collapse', background: '#fff', borderRadius: 10, overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' },
  th: { textAlign: 'left', padding: '12px 16px', background: '#f4f6f9', fontSize: 13, color: '#666' },
  td: { padding: '12px 16px', borderTop: '1px solid #f0f0f0', fontSize: 14 },
  badge: { padding: '3px 10px', borderRadius: 12, fontSize: 12, fontWeight: 600 },
  smallBtn: { padding: '6px 12px', marginRight: 6, border: '1px solid #ddd', background: '#fff', borderRadius: 5, fontSize: 12 },
  error: { background: '#ffe5e9', color: '#e94560', padding: '10px 14px', borderRadius: 6, marginBottom: 16 },
};
