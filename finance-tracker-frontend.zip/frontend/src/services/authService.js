import api from './api';

export const signup = (username, email, password) =>
  api.post('/auth/signup', { username, email, password });

export const login = (username, password) =>
  api.post('/auth/login', { username, password });
