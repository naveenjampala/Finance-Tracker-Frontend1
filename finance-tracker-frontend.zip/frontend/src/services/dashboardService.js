import api from './api';

export const getDashboardSummary = (month, year) =>
  api.get('/dashboard/summary', { params: { month, year } });
