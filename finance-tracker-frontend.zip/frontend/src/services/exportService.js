import api from './api';

const downloadFile = (response, filename) => {
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  link.remove();
};

export const exportCsv = async (month, year) => {
  const response = await api.get('/export/csv', { params: { month, year }, responseType: 'blob' });
  downloadFile(response, `transactions_${year}_${month}.csv`);
};

export const exportPdf = async (month, year) => {
  const response = await api.get('/export/pdf', { params: { month, year }, responseType: 'blob' });
  downloadFile(response, `report_${year}_${month}.pdf`);
};
